function showOptimizers(int)
% Show a list of JavaEvA optimizers accessible through the JEInterface
% and their access ID numbers.

javaeva.OptimizerFactory.showOptimizers
