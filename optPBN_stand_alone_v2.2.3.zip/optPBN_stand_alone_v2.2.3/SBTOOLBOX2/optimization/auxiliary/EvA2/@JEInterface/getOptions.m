function opts = getOptions(int)
% Return the current optimset structure used by the interface

opts = int.opts;