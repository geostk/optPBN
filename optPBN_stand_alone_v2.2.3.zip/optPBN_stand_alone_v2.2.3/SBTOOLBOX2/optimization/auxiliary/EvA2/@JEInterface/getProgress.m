function b = getProgress(int)
% Returns the number of function calls performed during optimization (not
% post processing)

b = int.mp.getProgress;
