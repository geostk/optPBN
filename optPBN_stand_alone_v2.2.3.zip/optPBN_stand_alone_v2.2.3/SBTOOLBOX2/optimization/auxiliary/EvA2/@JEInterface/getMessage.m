function str = getMessage(int)
% Get information string received from JavaEvA.

str = int.msg;
