function b = isFinished(int)
% Deprecated: optimization now runs synchronously. 
% Returns 1 if the optimization was finished, else 0

b = int.finished;
